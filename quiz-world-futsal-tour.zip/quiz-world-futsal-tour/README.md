# Quiz World Futsal Tour – Centre Ados de Bresles

Quiz façon « Qui veut gagner des millions » sur les 6 pays du World Futsal Tour
(Brésil, Japon, Espagne, Sénégal, Canada, Italie) : 120 questions, 20 tirées au
hasard par partie, record personnel, classement de la famille et classement
partagé de tout le centre.

## Contenu

- `index.html` : le jeu (questions, écrans, classements)
- `netlify/functions/scores.mjs` : enregistre et renvoie le classement partagé
- `netlify.toml`, `package.json` : réglages pour Netlify

## Mettre en ligne

1. Sur github.com, créer un dépôt (ex. `quiz-world-futsal-tour`).
2. « Add file » > « Upload files », glisser tout le contenu du dossier
   (en gardant le dossier `netlify/functions`), puis « Commit changes ».
3. Sur app.netlify.com : « Add new site » > « Import an existing project » >
   GitHub > choisir le dépôt > « Deploy ». Aucun réglage à changer.
4. Le site est en ligne en 1 à 2 minutes. Dans « Site configuration » >
   « Change site name », choisir par exemple `quiz-ados-bresles`
   (adresse : https://quiz-ados-bresles.netlify.app).

## Modifier les questions

Dans `index.html`, chercher `const Q=[`. Chaque ligne :
`["code pays","geo|cul|spo","Question ?","Bonne réponse","Faux 1","Faux 2","Faux 3"]`.
Enregistrer sur GitHub : Netlify remet le site à jour tout seul.

## Remettre le classement à zéro

Netlify > le site > « Blobs » > magasin `quiz-scores` > supprimer l'entrée `all`.
